#pragma once
#include <iostream>




void inicializarTablero1();
void inicializarTablero2();
void inicializarTablero3();

void mostrarTablero1();
void mostrarTablero2();
void mostrarTablero3();